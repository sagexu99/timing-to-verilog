"""Check cycle, pulse-width and integer-baud arithmetic from supplied timing limits."""

import argparse
import json
import math
from fractions import Fraction


def positive_integer(value):
    try:
        result = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("Expected an integer") from error
    if result <= 0:
        raise argparse.ArgumentTypeError("Value must be positive")
    return result


def positive_fraction(value):
    try:
        result = Fraction(value)
    except (ValueError, ZeroDivisionError) as error:
        raise argparse.ArgumentTypeError("Expected a finite number") from error
    if result <= 0:
        raise argparse.ArgumentTypeError("Value must be positive")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clock-hz", type=positive_integer, required=True)
    parser.add_argument("--baud-rate", type=positive_integer)
    parser.add_argument("--wait-us", type=positive_fraction, action="append", default=[])
    parser.add_argument("--sclk-high-cycles", type=positive_integer)
    parser.add_argument("--sclk-low-cycles", type=positive_integer)
    parser.add_argument("--min-pulse-fraction", type=positive_fraction)
    args = parser.parse_args()

    if (args.sclk_high_cycles is None) != (args.sclk_low_cycles is None):
        parser.error("Supply both SCLK high and low cycle counts")
    if args.min_pulse_fraction is not None:
        if args.sclk_high_cycles is None:
            parser.error("Pulse check requires both SCLK cycle counts")
        if args.min_pulse_fraction > Fraction(1, 2):
            parser.error("A shared high/low minimum fraction cannot exceed 0.5")

    if args.baud_rate is not None and args.baud_rate > args.clock_hz:
        parser.error("Integer baud divider must be at least one clock cycle")

    result = {"clock_hz": args.clock_hz, "waits": []}
    if args.baud_rate is not None:
        cycles_per_bit = args.clock_hz // args.baud_rate
        actual_baud = Fraction(args.clock_hz, cycles_per_bit)
        result["integer_baud"] = {
            "requested_baud": args.baud_rate,
            "cycles_per_bit": cycles_per_bit,
            "actual_baud": float(actual_baud),
            "error_percent": float((actual_baud / args.baud_rate - 1) * 100),
            "counter_bits_for_zero_to_n_minus_one": max(1, (cycles_per_bit - 1).bit_length()),
            "half_bit_compare_count": cycles_per_bit // 2 - 1,
            "half_bit_compare_nonnegative": cycles_per_bit >= 2,
        }
    for wait_us in args.wait_us:
        cycles = math.ceil(wait_us * args.clock_hz / 1_000_000)
        result["waits"].append({
            "requested_us": float(wait_us),
            "minimum_cycles": cycles,
            "counter_bits_for_zero_to_n_minus_one": max(1, (cycles - 1).bit_length()),
        })

    if args.sclk_high_cycles is not None:
        total = args.sclk_high_cycles + args.sclk_low_cycles
        clock_ns = Fraction(1_000_000_000, args.clock_hz)
        result["sclk"] = {
            "frequency_hz": float(Fraction(args.clock_hz, total)),
            "high_ns": float(args.sclk_high_cycles * clock_ns),
            "low_ns": float(args.sclk_low_cycles * clock_ns),
        }
        if args.min_pulse_fraction is not None:
            minimum_cycles = total * args.min_pulse_fraction
            result["sclk"].update({
                "minimum_pulse_ns": float(minimum_cycles * clock_ns),
                "high_pass": args.sclk_high_cycles >= minimum_cycles,
                "low_pass": args.sclk_low_cycles >= minimum_cycles,
            })

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
