# Timing-to-Verilog Implementation Notes

## Inputs and Target

Record source diagrams/documents, revisions, page numbers or page names, protocol role, HDL dialect, actual clock, and target rate. Distinguish user requirements, diagram evidence, existing behavior, and design assumptions.

## Ports and Handshakes

| Signal | Direction/clock domain | Active level or edge | Data-stability/acceptance condition | Reset behavior |
|---|---|---|---|---|

## Event and Cycle Mapping

| Diagram event/source | Reference edge and interval | Counter domain and RTL condition | Drive/release/sample action | Post-edge data/enable |
|---|---|---|---|---|

## Parameter Budget and Data Path

Record integer dividers, actual rates, error, counter ranges, setup/hold requirements, and tri-state/data delays. Use an asymmetric word to demonstrate bit or lane packing. List diagram/code conflicts and the selected basis.

## Source Files and Verification

Link RTL, the self-checking testbench, and run instructions. Record commands actually executed, passed or failed checks, reasons for changes, and checks not run. Describe busy-time requests, errors, recovery scope, and board inputs still required for physical timing analysis.
