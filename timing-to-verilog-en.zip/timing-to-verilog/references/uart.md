# UART Bit Timing and Midpoint Sampling Case Study

## Sources and Diagram/Code Differences

The sources are `More_ref/ref_uart/uart_tx.v`, `uart_rx.v`, and the “uart_tx波形图” and “uart_rx波形图” pages in `UART串口环回.vsdx`. These page names identify the transmit and receive waveform pages. The original code carries third-party copyright notices. This package retains mapping methods and applicability limits without copying the complete source.

The diagrams illustrate counter and sampling relationships, but must be checked against code. The TX diagram labels its stop bit as 15/16 of a bit and shows a final count of 815. The active TX completes when tx_cnt=9 and baud_cnt=N-1. With the default N=868, it counts through 867 and transmits a full stop bit. The RX diagram's final output annotation also differs from the internal example's bit pattern. Its annotated example value must not be the sole test oracle.

Explain the current implementation from its active statements. Generate new code from the confirmed frame format and interface requirements. If the user requests custom behavior such as early done from a diagram, define it separately from the on-wire stop-bit duration and next-frame acceptance.

## Bit Period, Format, and Error

The reference uses idle high, a low start bit, eight data bits LSB-first, no parity, and one stop bit, or 8N1. CLK_FREQ=100 MHz and UART_BPS=115200 produce the truncated integer divider N=868. The actual rate is approximately 115207.37 baud, an error of +0.0064004%. This is the nominal divider error. Receiver timing also depends on both endpoints' clock errors, synchronization delay, and jitter.

BAUD_CNT_MAX is the number of clock cycles per bit. baud_cnt runs from 0 through N-1, while tx_cnt/rx_cnt identifies bit positions. Keep bit indexes separate from system-cycle counts. The reference uses a fixed 16-bit baud counter, so higher clocks or lower baud rates require width checks. A small N can invalidate midpoint and synchronization assumptions. Establish the supported range for a new design.

## TX Acceptance, Latching, and Output Delay

On the uart_tx_en edge, the design latches data, asserts busy, and clears baud_cnt/tx_cnt. The output always block sees the old busy value on that edge, so the low start bit begins on the next system-clock edge. At a bit boundary, tx_cnt increments while the output block still uses the old tx_cnt. Trace that delay explicitly.

tx_cnt=0 sends the start bit, 1 through 8 send data bits 0 through 7, and 9 sends the stop bit. With the defaults, each bit lasts 868 cycles. busy clears after the stop bit completes, and TXD remains high.

The reference does not gate uart_tx_en with !busy. A request while busy overwrites tx_data_t and resets the counters. Holding en high repeatedly reloads data and clears the counters. Its caller therefore needs a single-cycle request while idle. For a new interface, define whether busy-time requests are rejected, queued, or otherwise handled, and keep state and output behavior consistent.

## RX Synchronization, Triggering, and Bit Centers

uart_rxd passes through d0, d1, and d2. The expression start_en=d2 & ~d1 & ~rx_flag detects a falling transition in the synchronization pipeline. The initial baud_cnt cycle depends on old values around rx_flag assertion. Data is sampled from d2. Put the start-detection path, counter origin, and synchronized-data path on the same timeline to avoid counting a shared delay twice.

rx_cnt=0 denotes the start bit, 1 through 8 denote data bits 0 through 7, and 9 denotes the stop bit. The reference samples data when baud_cnt=N/2-1. At the stop-bit midpoint, it clears rx_flag, pulses uart_rx_done for one system cycle, and transfers rx_data_t into uart_rx_data. The final data bit was already captured at the midpoint of rx_cnt=8, so the notification transfers the previously assembled byte.

The reference does not recheck a low start level at the half-start point, verify a high stop bit, or expose parity, framing-error, or overrun status. It demonstrates basic midpoint sampling rather than a complete noise-rejecting, error-detecting UART. For new implementations, provide start qualification, stop-bit checks, and error behavior as required. Invalid sampling or framing must be handled according to the promised data-valid contract.

## Verification Criteria

Decode TX with an independent serial model sampling at bit centers, without reading internal tx_cnt. Drive RX from an independent time base instead of sharing the DUT baud_cnt. Cover different start phases, consecutive frames, and the fast/slow ends of the allowed baud mismatch. Bytes 00, FF, 55, A5, 01, and 80 distinguish idle behavior, bit order, endpoint bits, and transitions.

Within the promised feature set, cover requests while busy, short start glitches, low stop bits, reset interruption, and consecutive bytes. TX-to-RX loopback is a supplemental check. Matching divider or bit-order errors can cancel between the two endpoints. Record unsupported behavior according to the interface contract instead of treating inputs outside a teaching module's stated scope as proof that it fails its intended task.
