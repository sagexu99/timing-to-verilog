# CUDA612C3 Timing-to-Verilog Case Study from a Validated Implementation

## Sources and Applicability

This case derives from the user-supplied CUDA612C3 product manual V1.8, `adc_get.v`, and `sda_cfg.v`. The user confirmed both RTL modules work in their tested setup. This case covers configuration and receive timing.

Printed pages 2-6 through 2-12 correspond to PDF pages 11 through 17. The main references are Figures 2-4-4, 2-4-6, 2-4-7, and 2-4-9, Tables 2-4-1 through 2-4-6, and sections 2.4.4 and 2.4.8. The original files reside in the project's `More_ref/` directory. This package contains the mapping notes, without embedding the original manual or RTL. Obtain the applicable original sources when using this device in another project.

The name clk_80m agrees with the manual's typical configuration. Calculations below assume 80 MHz and T=12.5 ns. The two modules do not specify the complete device-SCL forwarding path or constraints. Confirm external SCL phase and board-level margins in the top-level design.

## 1. Establish the Protocol and Clock Relationships

SDA carries configuration and pixel-correction input, FSL is frame synchronization, and SCL is the main clock. Their custom frame/row timing does not imply an I2C controller.

- sda_cfg updates state, counters, FSL, and SDA on negedge clk_80m. Figure 2-4-6 aligns FSL falling with SCL falling and presents the first frame-header bit at that event.
- adc_get detects FSL, accumulates AD data, and generates output controls on posedge clk_80m. It captures using the main clock and does not consume ADSCL.
- Table 2-4-1 specifies FSL/SDA setup, hold, and clock duty-cycle requirements. The input diagram is Figure 2-4-3 on PDF page 10. The output diagram is Figure 2-4-4 on PDF page 11. Read diagrams and tables together to establish reference edges.
- Section 2.4.8 also permits capture of AD using ADSCL rising edges. Main-clock capture and returned gated-clock capture can have different origins, gating, and leading words. Construct separate mappings for their first cycles.
- Use output delays for the applicable VDDIO when deriving an ADSCL sampling window. Typical values support nominal estimates only.

## 2. Convert Diagram Lengths into Configuration-State Intervals

In sda_cfg.v, cfg_cnt runs continuously across CFG_FH, CFG_F, and CFG_IDLE. The table gives old counter values used on each transmit-update edge.

| Segment | Manual meaning | Old cfg_cnt range | Length | Active-code mapping |
|---|---|---|---|---|
| Frame header | FH7 through FH0 | 0-7 | 8T | cfg_8b[7-cfg_cnt], value 0xAC |
| Global configuration | F127 through F0 | 8-135 | 128T | para_cfg[127-(cfg_cnt-8)] |
| Post-configuration gap | Wait before the first POC row | 136-313 | 178T | SDA=0 |
| First POC start | Relative to FSL falling | 314T from frame start | 3.925 us | Present PH7 after entering POC_PH |

The 128 configuration bits come from para_cfg. The commented 16-byte constant is a historical example. It is not the current input and does not automatically replace manual defaults. The port is indexed directly during transmission, so it must remain stable over the send window under a top-level update contract.

poc_cnt runs continuously across four states. One row maps as follows.

| Segment | Old poc_cnt range | Length | Output |
|---|---|---|---|
| POC_PH | 0-7 | 8T | PH7 through PH0, value 0x58 |
| POC_P | 8-2583 | 2576T = 644 x 4T | P3 through P0 for each column. The code repeats 4'b1000 |
| POC_IDLE | 2584-2591 | 8T | SDA=0 |
| POC_ITV | 2592-3007 | 416T | Retain the preceding output until the next row |

In Figure 2-4-7 and Table 2-4-6, the upper nibble 0101 of 0x58 selects per-column updates, and the lower nibble is POCA. Sending 4'b1000 for every column is this project's implementation of identical per-column values. It does not select the 1010 uniform-value mode.

Check the total `8+2576+8+416=3008T`. row_cnt runs from 0 through 516, giving 517 POC row periods. ROW_LEF counts 0 through 2693, giving 2694T. The complete FSL loop period is `314 + 517*3008 + 2694 = 518*3008T`, or 19.4768 ms at 80 MHz, approximately 51.34 Hz.

The manual's 532-row, 20.0032 ms example in section 2.4.4 is a typical 50 Hz configuration. The user-validated project uses 518 row periods. Record their respective conditions. start only initiates the transition out of IDLE. ROW_LEF subsequently returns to CFG_FH for continuous frames, so another start is not required for each frame.

## 3. Trace the First Receive Cycle from Frame Start

Section 2.4.8 and Figure 2-4-9 establish the first-row timing reference as `314T + 3*3008T = 9338T`. adc_get.v detects FSL falling with `fs_l_r && !fs_l`, enters WAIT, and uses the terminal comparison `9338-2`.

The -2 is a phase/state-latency alignment constant in this validated project. For a new implementation, tabulate FSL pin falling, edge detection, WAIT entry/exit, READ_8B, continuous shifting, and the consumer edge. Explain the compensation. A duration formula alone does not justify changing the baseline or treating -2 as a fixed device-protocol requirement.

The receive states last READ_8B=8T, READ_VALID=2576T, and READ_IDLE=424T, totaling 3008T. READ_IDLE combines the 8T trailer and 416T inter-row gap. row_cnt=0 through 511 means this receive state machine handles 512 rows as an application window. Record the physical 516-row array and blind row separately from the manual.

## 4. Reconstruct One Word from Four Lanes and Four Cycles

The per-pin labels in Figure 2-4-9 show each lane transmitting a portion of a word over time. The code accumulates data in four 4-bit shift registers.

| Capture cycle | ad3 | ad2 | ad1 | ad0 |
|---|---|---|---|---|
| 0 | D15 | D11 | D7 | D3 |
| 1 | D14 | D10 | D6 | D2 |
| 2 | D13 | D9 | D5 | D1 |
| 3 | D12 | D8 | D4 | D0 |

Each lane shifts using `{lane_reg[2:0], lane_in}`. After four captures, `{ad3_reg,ad2_reg,ad1_reg,ad0_reg}` yields D15:0. For 16'hA35C, the lane sequences are 1010, 0011, 0101, and 1100. Concatenating the four accumulated nibbles reproduces A35C. The instantaneous vector `{ad3,ad2,ad1,ad0}` is not a sequence of contiguous word nibbles.

Record the product's 14-bit digital-output specification separately from the protocol's 16-bit transfer word. Determine truncation and encoding from the actual configuration. G2B_EN selects Gray or binary encoding, so para_cfg and output interpretation must agree.

The manual text describes a 16'hFFFF header, a 16-bit row-number word, 644 pixels, and an 8T trailer. Its ADSCL capture expression also includes a 0000 preamble and its own trailing alignment. Use row numbers and sentinel words to verify the first-word window for the chosen reference clock. Equal 2592T lengths do not establish identical data slices.

## 5. Output Contract and Project Constants

- adc_read directly concatenates the four shift registers and changes continuously. adc_out is assigned internally but does not drive this port. Follow the active data path when adapting the interface.
- read_4t_cnt_r delays the phase by one cycle. adc_wr asserts when that value is 3 and the valid counter is within 1-2560, once every four cycles, nominally yielding 640 writes per row.
- adc_valid covers counts 1-2556, distinct from the 1-2560 adc_wr window. adc_hsync uses the independent row-counter window 128-3007. adc_vsync uses fs_l and the WAIT threshold 6015. Record each signal's semantics and retain its boundaries until the consumer contract is available.
- Verilog precedence in `state==READ_8B || state==READ_VALID && phase==3` keeps the phase counter cleared during READ_8B. Four-cycle phase counting occurs in READ_VALID. Grouping both states into the same phase-counting behavior would change the implementation.
- The project's output dimensions are 512 rows and 640 writes per row. These dimensions alone do not establish that it selects exactly the manual's suggested columns 2-641 and rows 2-513. Confirm input phase and downstream cropping.

## 6. Use the Case to Check Newly Generated RTL

For implementation or verification requests, construct stimulus independently from the manual and check behavior within the actual project's scope.

1. Check the FSL falling phase, MSB-first order of 0xAC and the 128-bit configuration, and configuration stability during transmission.
2. Check POC starting after 314T, row segments of 8/2576/8/416 cycles, endpoint columns, 517 row iterations, frame tail, and next-frame spacing.
3. Use varying row numbers and per-pixel 16-bit data with distinguishable endpoint bits to verify four-lane/four-cycle reconstruction and capture phase.
4. Check raw pixels per row, application wr count, valid windows, and frame/row synchronization separately. Include pre-edge values from nonblocking assignments when a consumer captures on the same clock edge.
5. Compare observable outputs against the user-validated baseline under identical stimulus. Explain initial phase offsets, discarded headers, and final-word completion. Report an HDL simulation pass only after actually running HDL simulation.

This reference is based on manual diagram inspection, static state-by-state analysis, and word-mapping calculations. The user's confirmation of a working baseline applies to their tested setup. It does not establish validation for every frequency, configuration, or downstream connection.
