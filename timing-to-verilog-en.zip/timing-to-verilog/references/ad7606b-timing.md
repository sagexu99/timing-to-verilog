# AD7606B First-Bit and Four-Lane Readout Case Study

This case derives from the earlier project's review of the 74-page AD7606B Rev. B datasheet and ad7606b_capture.sv. Recheck specific values against the source revision used in each new project. The material supports timing-to-code mapping.

- Pages 10-11, Table 5 and Figures 6/7, specify clock frequency, high/low widths, input setup/hold, and output-access delays under stated VDRIVE and load conditions. DOUT tri-state enable delay alone does not establish data-valid timing under all conditions.
- Page 38 describes the MSB being presented by CS falling, followed by subsequent bits advancing on SCLK rising. If the FPGA generates SCLK and captures the old DOUT on the same internal edge, analyze pre-edge data and board-level hold timing. If capture follows the update edge, budget access delay and setup margin. Determine first-bit treatment and total edge counts for the chosen architecture.
- In four-lane mode, DOUTA carries CH1/2, B carries CH3/4, C carries CH5/6, and D carries CH7/8. Without status or CRC, 32 parallel SCLK cycles read all channels and may be divided into two 16-bit frames. This differs from CUDA612C3, where each lane carries a portion of the same word.
- Pages 39-41 define register-mode entry, pipelined readback, and return to ADC mode. The earlier sequence 0x4100, 0x0210, 0x0000 reads STATUS, writes CONFIG=0x10, and exits register mode. Status and CRC affect frame length, so fixed 16-bit loops depend on configuration.
- Page 8, Table 3, and page 39 allow readout to extend into the next conversion, but it must finish before the next BUSY falling edge updates the data and must satisfy the final-LSB margin. Consecutive BUSY falling edges are separated by the sample period plus the next conversion time minus the current conversion time. A typical conversion time is not a guaranteed minimum.
- The earlier 200 MHz implementation produced a 20 ns high interval, 10 ns low interval, and 30 ns read-clock period. The low interval failed the supplied 40% pulse-width condition. This conclusion applies to that state sequence and does not characterize all four-lane drivers.

Verify BUSY, CS, SCLK, all four data lanes, and output valid on one timeline. Use distinct channel words, distinguishable endpoint bits, and varying consecutive conversion times to detect mixed result groups.
