# I2C Four-Phase Timing Case Study

## Source Material

The project sources are `More_ref/ref_i2c/i2c_dri.v` and `EEPROM读写测试实验Visio框图.vsdx`. Relevant page names are “时钟波形” (clock waveforms), “写控制命令” (write control command), “发送字地址” (word address), “写数据” (write data), “读控制命令” (read control command), “读数据” (read data), and “SDA三态门” (SDA tri-state interface). This case compares diagrams with active code cycle by cycle. It does not claim HDL simulation or coverage of all I2C modes. The original code carries third-party copyright notices. This package contains behavioral analysis rather than a copy of that source.

## Divider Domains and Four Phases

The defaults are CLK_FREQ=100 MHz and I2C_FREQ=250 kHz. The active expression computes `(CLK_FREQ/I2C_FREQ) >> 2` using integer arithmetic, then assigns it to the 9-bit clk_divide. dri_clk toggles every floor(clk_divide/2) system clocks. At the defaults, clk_divide=100 and the half-period is 50 system cycles. Thus dri_clk is 1 MHz, and four rising edges of dri_clk define an ordinary 4 us bus-bit period.

Evaluate the actual expression, width truncation, and clock toggling. CLK_FREQ/clk_divide alone does not determine SCL frequency. Recalculate behavior for non-integer ratios, odd divider values, and overflow beyond 9 bits. cur_state, data registers, and done operate in the dri_clk domain. Requests and consumers must use that domain or a suitable handshake.

| cnt within an ordinary byte segment | Action | Timing meaning |
|---|---|---|
| 4k | Present bit[7-k] while SCL is low | Prepare data |
| 4k+1 | Raise SCL | Begin the high phase. In the read state, capture the pre-edge sda_in value here |
| 4k+2 | Keep SCL high | Hold data or observe a response |
| 4k+3 | Lower SCL | End this bit |

For data, k=0 through 7. ACK occupies the ninth bit and requires ownership transfer. A control segment containing START offsets the first data bit to cnt=4, so its ACK counts differ. Use a segment-specific event table.

## Transaction Order and Direction

A write transaction contains START, a 7-bit device address plus W, ACK, an optional high word-address byte, the low word-address byte, ACK, data, ACK, and STOP, with ACK handling for each transmitted address byte. A read first sets the word address in the write direction, then issues repeated START, the device address plus R, ACK, one received byte, controller NACK, and STOP. The reference supports single-byte transactions. Additional bytes require a corresponding protocol loop.

In st_sladdr, cnt=1 generates START, cnt=3 lowers SCL, and cnt=4 through 32 sends the device address and W=0. cnt=36 releases SDA, 37 raises SCL, 38 samples ACK and sets st_done, and 39 lowers SCL and clears the counter. st_done is registered. The next state takes effect on the following dri_clk edge, when the old state still performs its cnt=39 action.

Ordinary address/write-data segments present their eight bits at cnt=0 through 28, release SDA at 32, raise SCL at 33, observe ACK and assert st_done at 34, then lower SCL at 35 before the next state takes over. Explicitly map these exit edges that still execute the old state's logic.

In st_addr_rd, cnt=0/1/2/3 sets SDA high, SCL high, SDA low, and SCL low, producing repeated START. st_data_rd captures sda_in at cnt=1/5/.../29, takes controller ownership at 32 to send NACK, and transfers the complete data_r into i2c_data_r at 35. st_stop raises SDA while SCL is high. i2c_done is asserted at cnt=16.

## Electrical Behavior and Simplifications

The reference expression `sda_dir ? sda_out : 1'bz` can actively drive high, drive low, or release the line. It illustrates ownership, but active-high driving does not establish a general open-drain implementation. For newly generated Standard/Fast/Fm+ I2C SDA, use a top-level driver that only pulls low or releases the line, including release for target ACK. Push-pull SCL requires explicit conditions such as a single controller and no clock stretching. If stretching is supported, observe actual SCL before advancing the phase.

i2c_ack=1 means a NACK was detected and remains set until the next accepted request clears it. The state machine does not abort automatically on NACK. i2c_done indicates sequence completion, so it does not establish success. bit_ctrl is read directly during state transitions and must remain stable under the caller's contract. The direction flag, address, and write data are latched on request acceptance.

State whether a new module supports clock stretching, multi-controller arbitration, multiple bytes, and timeout handling. Implement the current requirements without claiming capabilities absent from this teaching reference. For EEPROM writes, device write-cycle completion or ACK polling is separate from bus STOP/done.

Electrical behavior, START/STOP, ACK, and clock stretching were cross-checked against the corresponding subsections of section 3.1 in NXP UM10204 Rev.7.0. New projects must also satisfy the target device's speed-mode and setup/hold requirements. [NXP I2C-bus specification](https://www.nxp.com/docs/en/user-guide/UM10204.pdf)

## Verification Criteria

Model target ACK and read data on a resolved line with a pull-up. Check SDA output enable, resolved line values, and contention. Use asymmetric bytes to verify MSB-first order. Cover 8/16-bit word addresses, writes, repeated-START reads, NACK at different stages, and controller NACK after the last received byte. Check completion pulses, error latching, and consumer clock domains separately. If stretching is required, add actual SCL waits and timeout cases during the high phase.
