# From Diagram Events to Synthesizable RTL

## 1. Build an Event Table

Establish the diagram's role and viewpoint, such as controller transmission, target output, device pins, or internal registers. Record the source diagram, manual revision, page number, or VSDX page name.

| Event/source | Pin reference edge | System/internal counter domain | Interval and length | Drive/release/sample action | Data-bit mapping | Conditions or margin |
|---|---|---|---|---|---|---|

Use half-open intervals [start,end). State whether the trigger cycle is included, whether comparison occurs before incrementing, and how state entry/exit affects timing. For folded or omitted waveform sections, use annotated cycle counts instead of measuring image proportions. Build separate timelines for concurrent processes, such as configuration and continuous capture, then align them.

List invariants, such as data remaining stable while SCL is high, a transmitted start bit lasting one bit period, or a returned clock producing edges only within its valid window. Preserve Min/Typ/Max values and their conditions. Treat output-enable delays and data-access delays separately.

## 2. Define the Interface Contract

Specify clocks, reset polarity and synchronization, input-valid windows, request acceptance, output-data timing relative to enables, and whether busy/done/error signals pulse or remain asserted. Define reset interruption, requests while busy, missing responses, and missing data according to the task's actual requirements.

Establish when requests are latched, whether data may change within a frame, and whether start initiates one transaction or continuous operation. Consult existing consumers or specifications. Use synchronization or handshakes appropriate to the data crossing clock domains. Prefer the system clock with clock enables for new designs. If preserving a derived-clock design, establish domain relationships and the basis for generated-clock constraints.

For bidirectional pins, describe output data and output enable independently. Use ordinary logic for internal signals and place tri-state behavior at an appropriate top-level I/O boundary. For source-synchronous interfaces, analyze the returned clock and data-valid window before choosing a capture architecture. Do not reduce a returned capture clock to an arbitrary synchronized pulse.

## 3. Align Control and Data Cycle by Cycle

For nonblocking assignments, construct three columns showing pre-edge values, conditions evaluated at the edge, and post-edge values. Matching positions in a waveform drawing do not eliminate a register-cycle delay.

- N transfers normally use counts 0 through N-1. For counters spanning segments, segment length is the difference between cumulative boundaries.
- Explain transmit order, receive shift direction, and final packing with the same asymmetric word. Check first/last bits, first/last bytes, and the first/last group across multiple lanes.
- If a port directly exposes shift registers, its data may change each cycle. wr/valid determines when the data is consumable. A downstream register sampling on the same edge sees pre-edge values, so extend the analysis to that consumer.
- Midpoint sampling includes edge-detection and synchronization-pipeline timing. Half a baud period alone does not determine the capture instant.
- Verilog parses `A || B && C` as `A || (B && C)`. Add explicit parentheses in new code and interpret existing baselines by their actual branches.
- Padding words, headers, row numbers, and blanking intervals provide alignment checkpoints. Distinguish the physical frame from application cropping.

## 4. Budget Parameters and Implement Logic

Derive integer cycle counts from the target timing. Round minimum durations upward and choose dividers that satisfy maximum-frequency limits. Check maximum-duration bounds and error tolerance separately. For a UART using integer truncation, report actual baud rate and error. If the error budget is exceeded, choose a more suitable integer divider or fractional clock-enable scheme according to project requirements.

Check division by zero, zero divider results, odd dividers, high/low pulse widths, counter widths, and output indexing. Add necessary checks for supported parameter ranges. Simulation delays using # do not implement synthesizable timing.

Let protocol states define transaction segments and bit/phase counters define events within a segment. Follow the existing project's structure. Keep addresses, data, direction changes, and recovery behavior readable. Extract a reusable byte/bit engine only when repetition warrants it.

When device constraints are missing, identify required input/output delays or clock relationships and show their derivation. Avoid inventing pins, I/O banks, input delays, or false paths. Establish cycle-level function and physical timing closure separately.

## 5. Verify and Iterate

Check the HDL tools actually available and the project's existing commands before selecting compilation and simulation entry points. Preserve source encoding or decode comments correctly so corrupted text is not mistaken for protocol notation.

Construct self-checking models independently from the diagram and protocol semantics. Do not duplicate the DUT state machine. Use distinguishable data such as 00, FF, asymmetric words, opposite endpoint bits, and successive different values. Model bidirectional buses with pull-ups and genuine multi-driver resolution. Looping a DUT output into its input is not a target-device model.

Within the requested scope, verify the following observable behavior.

- Each request is accepted once, with input latching and busy/done behavior matching the contract.
- Headers, payloads, responses, padding, and termination occur in the correct order and for the correct duration.
- Bit order, packing, endpoint data, valid enables, and consumer sampling edges align.
- Boundary-valid timing, supported dividers, continuous transactions, and asynchronous input arrival phases behave as specified.
- Requests while busy, timeout/no-response cases, reset interruption, and recovery follow the promised interface behavior.
- I2C checks cover ACK ownership, NACK handling, and bus contention. UART checks cover stop bits, false starts, and allowed baud mismatch. Frame/row streams check row numbers, missing words, and cross-frame alignment.

Turn diagram/code discrepancies into explicit acceptance criteria. Explain an existing implementation from its active statements. Generate new implementations from the confirmed target requirements and protocol. Material unresolved differences require user input. After a failure, fix the implementation and rerun affected checks. Do not alter expected values merely to obtain a pass.

For implementation requests, deliver synthesizable RTL, a corresponding self-checking testbench, run instructions, and concise notes explaining assumptions and edge mappings. Respect requests limited to analysis or a small snippet. If tools are missing, provide runnable commands and accurately report execution status. Python calculations and manual inspection do not establish an HDL simulation pass.
