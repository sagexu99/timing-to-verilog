---
name: timing-to-verilog
description: Use this skill when the user says "根据时序图生成Verilog代码" or "跟据时序图生成Verilog代码", asks to generate Verilog from a timing diagram, or requests synthesizable Verilog/FPGA logic from waveforms, interface timing, protocol diagrams, or datasheet timing. Covers I2C, UART, SPI, custom serial/parallel buses, sensors, memories, and other devices, including ADCs. Also use it to refine timing-to-code mappings against existing RTL. A datasheet upload alone, power or register summaries, translation, or drawing without an RTL implementation request does not trigger this skill.
---

# Generate Verilog from Timing Diagrams

Map diagram events, protocol requirements, and existing implementations into synthesizable RTL with explicit drive and sampling times. Keep user-facing explanations in Chinese by default. Use Verilog-2001 unless the user requests SystemVerilog or the existing project uses it. Follow the project's module names, interfaces, and directory conventions.

## Start with the User's Materials

Read the diagrams, accompanying text and timing tables, existing RTL, top-level clock settings, and clock/pin constraints. Establish protocol roles, signal directions, data flow, and reference clocks. Signal names such as SCL and SDA alone do not identify I2C. A sufficiently detailed timing diagram can support implementation without a complete datasheet.

When the user simply asks to generate Verilog from an available diagram, extract the requirements and proceed. If a missing frequency, width, polarity, or handshake affects correctness, first search the project. Ask only the necessary questions that remain, while completing independent specifications or a parameterized skeleton. Identify assumptions explicitly instead of presenting them as device requirements.

For VSDX files, locate named pages and embedded images, then inspect the actual waveforms. Prefer read-only export of relevant pages through an available Visio installation, or use another available renderer. XML text extraction alone cannot establish line geometry, edges, or alignment. If visual inspection is unavailable, identify the waveform conclusions that remain unverified. For PDFs and screenshots, inspect the original page and cross-check tables and footnotes.

## Load References as Needed

- For every implementation, read [From diagrams to RTL](references/workflow.md) and build the event table.
- For I2C transfers, ACK, open-drain signaling, and four-phase control, read the [I2C case study](references/i2c.md).
- For UART transmit/receive logic, midpoint sampling, and baud counters, read the [UART case study](references/uart.md).
- For frame/row scanning, pixel configuration, or word reconstruction across lanes and cycles, read the [CUDA612C3 case study](references/cuda612c3-timing.md). Its device-specific numbers apply only to that device.
- For AD7606B first-bit presentation, register mode, and four-lane readout, read the [AD7606B timing case study](references/ad7606b-timing.md).

Use the cases for their mapping methods and applicability limits. Derive a new protocol's event table from its own diagrams and specifications.

## Delivery Checklist

- [ ] Record source files, figure numbers or VSDX page names. Establish t=0, clock frequency/phase, port directions, reset behavior, widths, bit order, and protocol roles.
- [ ] Decompose the diagram into transactions, segments, words, bits/cycles, or frames/rows. Define cycle intervals and edge mappings for payloads, headers, trailers, responses, blanking, and cropping.
- [ ] Trace existing code using pre-edge counter and register values. Identify input latching, output driving, sampling, valid/done/busy timing, and downstream consumption edges.
- [ ] Implement synthesizable RTL within the requested scope. Reuse project logic. Treat user-validated implementations as baselines and explain differences before changing them. Prefer one system clock with clock enables for new logic. Handle actual returned or forwarded clocks using their clock domains and constraints.
- [ ] Use the relevant sections of the [delivery template](assets/timing-contract.md) to document the interface, event table, timing budget, assumptions, and run instructions. Match the amount of documentation to the task.
- [ ] Run available syntax checks, simulations, or project checks. For implementation tasks, provide a self-checking testbench by default, follow the verification rules in [From diagrams to RTL](references/workflow.md), fix failures, and recheck affected behavior.

## Common Sources of Incorrect RTL

- One diagram bit period may contain four internal phases, a half-bit sampling interval, or several serial fragments. Label each counter's clock domain and unit. Keep system cycles, derived-clock cycles, and bus bit periods distinct.
- State conditions, counter updates, and data registers commonly use old values on the same edge. N cycles usually require counts 0 through N-1. Counters spanning states use cumulative boundaries. Explain validated -1/-2 offsets cycle by cycle.
- When a diagram conflicts with code, record the discrepancy and the chosen basis. Teaching diagrams, historical comments, and parameter examples do not override active code or the target protocol automatically. Implement the unambiguous portions while resolving material uncertainty.
- Establish bit order, lane order, byte order, transfer width, and effective resolution separately. Use asymmetric known data to check endpoints, channels, packing, and signed interpretation.
- Driving SDA high and releasing SDA have different electrical effects. Check input values, output enables, and high-impedance intervals on bidirectional pins.
- Budget synchronous serial readout, asynchronous UART midpoint sampling, and source-synchronous parallel lanes according to their actual timing relationships. A control synchronizer is not a substitute for a high-speed data-capture architecture.
- Define transaction completion, ACK success, complete-word validity, and window validity separately. A shared signal name such as done or valid does not establish equivalence.
- Calculate divider truncation, counter width, parameter limits, and accumulated frame error. Relative waveform correctness still requires actual device and board delays to establish pin-level timing closure.

## Calculations and Final Reporting

For waits, counter widths, pulse widths, or UART integer dividers, run [timing_check.py](scripts/timing_check.py). It requires only the Python 3 standard library. Supply values from the current protocol and project.

```bash
python scripts/timing_check.py --clock-hz 100000000 --baud-rate 115200
python scripts/timing_check.py --clock-hz 200000000 --wait-us 0.0051 --sclk-high-cycles 4 --sclk-low-cycles 2 --min-pulse-fraction 0.4
```

Wait calculations round up to satisfy >= the requested duration. A strict > requirement needs another cycle or an explicit margin. Counter widths assume counting from 0 through N-1. The baud calculation evaluates floor(Fclk/baud) only. Fractional division and error-tolerance verification require separate analysis.

In the final response, link the source files, testbench, and necessary notes, and report commands actually run and their results. Report static inspection, HDL simulation, synthesis, implementation timing analysis, and hardware testing according to their actual completion status.

When maintaining the trigger description, use the [trigger examples](evals/trigger-queries.json). Their labels express expected behavior. Actual activation requires observing whether the host loads this SKILL.md. Keyword matching is not a measurement of activation rate.
